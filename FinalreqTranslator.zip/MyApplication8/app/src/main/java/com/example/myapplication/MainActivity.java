package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText editTextName;
    Button btnClick;
    TextView textName;
    String result;
    private String hello = "Hello";

    private String hi = "Hi";

    private String hru = "How are you";
    private String m = "Good morning";
    private String eve = "Good evening";
    private String y = "Yes";
    private String n = "No";
    private String ty = "Thank you";
    private String wc = "You're welcome";
    private String em = "Excuse me";
    private String sry = "Sorry";
    private String sry1 = "I am sorry";
    private String wiyn = "What is your name?";
    private String mni = "My name is ";
    private String wdys = "What did you say";
    private String today = "Today";
    private String tom = "Tomorrow";
    private String yesterday = "Yesterday";
    private String now = "Now";
    private String before = "Before";
    private String later = "Later";
    private String family = "Family";
    private String one = "One";
    private String two = "Two";
    private String three = "Three ";
    private String four = "Four ";
    private String five = "Five";
    private String six = "six ";
    private String seven = "Seven ";
    private String eight = "eight";
    private String nine = "nine ";
    private String ten = "ten ";














    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextName =(EditText)findViewById(R.id.editTextName);

        btnClick = (Button) findViewById(R.id.btnClick);

        textName = (TextView) findViewById(R.id.textName);

        btnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextName.getText().toString();

                if (name.equalsIgnoreCase(hello) || name.equalsIgnoreCase(hi))  {
                    textName.setText("Kon'nichiwa \n こんにちは");


                } else if (name.equalsIgnoreCase(hru)) {
                    textName.setText("Ogenkidesuka \n お元気ですか");

                } else if (name.equalsIgnoreCase(m)) {
                    textName.setText("Ohayōgozaimasu \n おはようございます");

                } else if (name.equalsIgnoreCase(eve)) {
                    textName.setText("Konbanwa \n こんばんは");

                } else if (name.equalsIgnoreCase(wc)) {
                    textName.setText("Dōitashimashite \n どういたしまして");

                } else if (name.equalsIgnoreCase(y)) {
                    textName.setText("Hai \n はい");

                } else if (name.equalsIgnoreCase(n)) {
                    textName.setText("Bangō \n 番号");

                } else if (name.equalsIgnoreCase(ty)) {
                    textName.setText("Arigatō \n ありがとう");

                } else if (name.equalsIgnoreCase(em)) {
                    textName.setText("Sumimasen \n すみません");

                } else if (name.equalsIgnoreCase(sry) || name.equalsIgnoreCase(sry1)) {
                    textName.setText("Gomennasai \n ごめんなさい");

                } else if (name.equalsIgnoreCase(wiyn)) {
                    textName.setText("O-namae wa nan desu ka \n おなまえはなんですか");

                } else if (name.equalsIgnoreCase(mni)) {
                    textName.setText("Watashinonamaeha \n 私の名前は");

                } else if (name.equalsIgnoreCase(wdys)) {
                    textName.setText("Nante iimashita ka \n なんていいましたか");

                } else if (name.equalsIgnoreCase(today)) {
                    textName.setText("kyou \n 今日");

                } else if (name.equalsIgnoreCase(tom)) {
                    textName.setText("ashita \n 明日");

                } else if (name.equalsIgnoreCase(yesterday)) {
                    textName.setText("kinou \n 昨日");

                } else if (name.equalsIgnoreCase(now)) {
                    textName.setText("ima \n 今");

                } else if (name.equalsIgnoreCase(before)) {
                    textName.setText("mae ni \n 前に");

                } else if (name.equalsIgnoreCase(later)) {
                    textName.setText("ato de \n 後で ");

                } else if (name.equalsIgnoreCase(family)) {
                    textName.setText("kazoku \n 家族 ");

                } else if (name.equalsIgnoreCase(one)) {
                    textName.setText("ichi \n いち ");

                } else if (name.equalsIgnoreCase(two)) {
                    textName.setText("ni \n に");

                } else if (name.equalsIgnoreCase(three)) {
                    textName.setText("san \n さん");

                } else if (name.equalsIgnoreCase(four)) {
                    textName.setText("shi \n し");

                } else if (name.equalsIgnoreCase(five)) {
                    textName.setText("go \n ご ");

                } else if (name.equalsIgnoreCase(six)) {
                    textName.setText("roku \n ろ ");

                } else if (name.equalsIgnoreCase(seven)) {
                    textName.setText("nana \n なな ");


                } else if (name.equalsIgnoreCase(eight)) {
                    textName.setText("hachi \n はち ");

                } else if (name.equalsIgnoreCase(nine)) {
                    textName.setText("ku \n く");

                } else if (name.equalsIgnoreCase(ten)) {
                    textName.setText("juu \n じゅう");
                } else {
                    textName.setText("Words Not found");
                }




            }




        });






    }


}